"""Computing fairness measures on law school data set."""

import argparse
import lawschool_parser
import numpy as np
import pandas as pd

import fairness
import fairness_plotter

def parse_args():
  p = argparse.ArgumentParser()
  p.add_argument('--data_location',
                 type=str,
                 default=lawschool_parser.DATA_FILE)
  p.add_argument('-t', '--test',
                 action='store_true',
                 default=False)
  p.add_argument('-p', '--plots',
                 action='store')
  return p.parse_args()

def main(args):
  raw_data = lawschool_parser.parse_file(args.data_location)
  data = raw_data[['race', 'sander_index', 'last_pf']]  # Restrict to important columns
  data = data[data.notnull().all(1)]                    # Drop nans

  races = 'White Black'.split()
  print 'Average academic indices:'
  print data.groupby('race').mean()['sander_index'].loc[races]

  data = fairness.FairnessData.from_individuals(data, races, 0.025)

  labels = dict(success='bar passage',
                success_people = 'bar-passers',
                score='academic index',
                longscore='Academic index',
                fail_people='bar-failers',
                classifier_outcome='admitted'
  )
  plotter = fairness_plotter.FairnessPlotter(data, labels)
  plotter.plot_figures(0.94, None if args.test else 'figs/lawschool-',
                         args.plots.split() if args.plots else None,
  )



if __name__ == '__main__':
  main(parse_args())
