from .flaskr import app
from flask import Blueprint
from .flaskr import test_1
from .flaskr import test_2
routes = Blueprint('routes', __name__)

# from .compas import *
# from .fairness import *
# from .fairness_plotter import *
