"""Library for testing and measuring (conditional) independence."""

import math
import numpy as np
from scipy.stats import chi2
from itertools import product


def arrays_to_counts(*arrs):
  """Transform a set of arrays to a count table.

  Args:
    *arrs: A sequence of arrays with nonnegative integer values.

  Returns:
    Array with dimension equal to the number of arrays passed in.
  """
  assert all(len(x) == len(arrs[0]) for x in arrs)
  return np.histogramdd(arrs, [np.arange(int(np.max(x))+2) for x in arrs])[0]


def likelihood_ratio_statistic(counts):
  """Compute likelihood ratio statistic from two-dimensional count table.

  Args:
    counts: Two-dimensional table of unnormalized counts.

  Returns:
    Float. Likelihood ratio test statistic.
  """
  T = 0.0
  for (i, j) in product(range(counts.shape[0]), range(counts.shape[1])):
    ratio_num = 1.0 * counts[i, j] * np.sum(counts)
    ratio_denom = 1.0 * np.sum(counts[i, :]) * np.sum(counts[:, j])
    T += counts[i, j] * np.log(ratio_num/ratio_denom)
  return 2.0 * T


def pearson_statistic(counts):
  """Compute Pearson independence test statistic for two discrete features.

  Data are summarized by two-dimensional count table.

  Args:
    counts: Two-dimensional table of unnormalized counts.

  Returns:
    Float. Pearson independence test statistic.
  """
  T = 0.0
  for (i, j) in product(range(counts.shape[0]), range(counts.shape[1])):
    e_ij = 1.0*np.sum(counts[i, :]) * np.sum(counts[:, j]) / np.sum(counts)
    T += (counts[i, j] - e_ij)**2 / e_ij
  return T


def chi2_p_value(test_statistic_value, df=1):
  """Compute p-value of chi2 test with `df` degrees of freedom."""
  return 1.0 - chi2.cdf(test_statistic_value, df=df)


def test_conditional_independence(counts):
  """Compute Pearson tests of independence.

  Assumes counts is 2d or 3d array. If 2d, do a single Pearson test of
  independence. Else, compute a p-value for each test conditional on
  one value of the third attribute. Report minimum p-value after Bonferroni
  correction.

  Args:
    counts: Multi-dimensional array of nonnegative integers.

  Returns:
    Float.
  """
  if len(counts.shape) == 2:
    return chi2_p_value(pearson_statistic(counts))
  else:
    assert len(counts.shape) == 3

  p_values = []
  for k in range(counts.shape[-1]):
    p_value = chi2_p_value(pearson_statistic(counts[:, :, k]))
    if not math.isnan(p_value):
      p_values.append(p_value)
  #print 'P values =', p_values
  return counts.shape[-1] * np.min(p_values)


def wasserman_delta(counts):
  """Compute MLE for Wasserman's delta function measuring independence.

  Assumes counts is 2d or 3d array. If 2d, this function measures distance from
  independence between two features given by the counts table. If 3d, it
  measures distance from conditional independence of the first two features
  given the third.

  See [Wasserman, "All of Statistics"] for discussion.

  Args:
    counts: Multi-dimensional array of nonnegative integers.

  Returns:
    Float.
  """
  assert len(counts.shape) in [2, 3]
  if len(counts.shape) == 2:
    counts = np.expand_dims(counts, -1)
  deltas = []
  for k in range(counts.shape[-1]):
    avg_counts = counts / (1.0 * np.sum(counts[:, :, k]))
    delta = 0.0
    for (i, j) in product(range(counts.shape[0]), range(counts.shape[1])):
      product_prob = np.sum(avg_counts[i, :, k]) * np.sum(avg_counts[:, j, k])
      delta += np.abs(avg_counts[i, j, k] - product_prob)
    deltas.append(0.5*delta)
  return np.max(deltas)
