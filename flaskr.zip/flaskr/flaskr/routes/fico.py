"""Computing fairness measures on law school data set."""

from __future__ import print_function
import argparse
import math
import numpy as np
import pandas as pd
from conditional_independence import arrays_to_counts
from conditional_independence import wasserman_delta
from conditional_independence import test_conditional_independence
import pylab
import fairness
import fairness_plotter

if __name__ != '__main__':
  pylab.ion()

DATA_DIR= r'F:/intern/equalop-share/data/FICO/csv/'

def parse_args():
  p = argparse.ArgumentParser()
  p.add_argument('--data_location',
                 type=str,
                 default=DATA_DIR)
  p.add_argument('-t', '--test',
                 action='store_true',
                 default=False)
  p.add_argument('--file_type',
                 action='store',
                 default='pdf')
  p.add_argument('-p', '--plots',
                 action='store')
  return p.parse_args()

# Should we use the location-based version?
# Original paper used all-account data

perf = 'Figure_6.A._TransRisk_Score-_Any-Account_Performance_(Percent_Bad),by_Demographic_Group- - Race_or_ethnicity_(SSA_data).csv'
CUTOFF = 0.82

# Perhaps we should switch to modified-new-account
#perf = 'Figure_6.E._TransRisk_Score-_Modified_New-Account_Performance_(Percent_Bad),by_Demographic_Group- - Race_or_ethnicity_(SSA_data).csv'
#CUTOFF = 0.975

files = dict(cdf_by_race = 'Figure_3.A._TransRisk_Score-_Cumulative_Percentage,_by_Demographic_Group- - Race_or_ethnicity_(SSA_data).csv',
             performance_by_race = perf,
             overview='overall.csv'
)

def cleanup_frame(frame):
  """Make the columns have better names, and ordered in a better order"""
  frame = frame.rename(columns={'Non- Hispanic white': 'White'})
  frame = frame.reindex_axis(['Asian', 'White', 'Hispanic', 'Black'], axis=1)
  #frame = frame[['Asian', 'White', 'Black']]
  return frame

def read_totals():
  """Read the total number of people of each race"""
  frame = cleanup_frame(pd.DataFrame.from_csv(DATA_DIR+files['overview']))
  return {r:frame[r]['SSA'] for r in frame.columns}

def convert_percentiles(idx):
  pdf = [(300, 2.1),
         (350, 4.2),
         (400, 5.4),
         (450, 6.5),
         (500, 7.9),
         (550, 9.6),
         (600, 12.0),
         (650, 13.8),
         (700, 17.0),
         (750, 15.8),
         (800, 5.7),
         (850, 0),
         ]
  def convert_one(x):
    partial = 0
    for ((v, s), (v2, _)) in zip(pdf, pdf[1:]):
      if partial + s >= x:
        return v + (v2-v) * (x - partial) / s
      partial += s
  return np.array(list(map(convert_one, idx)))

def parse_data(data_dir=DATA_DIR):
  """Parse sqf data set."""

  cdfs = cleanup_frame(pd.DataFrame.from_csv(data_dir+files['cdf_by_race']))
  performance = 100-cleanup_frame(pd.DataFrame.from_csv(data_dir+files['performance_by_race']))
  return (cdfs/100., performance/100.)

def get_plotter(do_convert_percentiles=True):
  data_pair = parse_data()
  totals = read_totals()

  if do_convert_percentiles:
    for v in data_pair:
      v.index = convert_percentiles(v.index)
  data = fairness.FairnessData(data_pair[0], data_pair[1], totals)
  labels = dict(success='non-default',
                success_people = 'non-defaulters',
                score='FICO score',
                longscore='FICO score',
                fail_people='defaulters',
                classifier_outcome='loan'
  )
  plotter = fairness_plotter.FairnessPlotter(data, labels)
  return plotter

def main(args):
  # mrtz: changed size
  #pylab.figure(figsize=(15, 8))
  pylab.figure(figsize=(15, 6))
  #fairness_plotter.rc('lines', marker='o')
  plotter = get_plotter()
  plotter.plot_figures(CUTOFF, None if args.test else 'figs/fico-',
                       args.plots.split() if args.plots else None,
                       plot_kwargs=dict(roc=dict(xlim=(0, 0.25), ylim=(0.4, 1.0))),
                       file_type=args.file_type,
)

if __name__ == '__main__':
  main(parse_args())
