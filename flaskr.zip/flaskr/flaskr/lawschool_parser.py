"""Parsing information for law school dataset"""

from __future__ import print_function
import pandas

DATA_FILE = 'F:/intern/equalop-share/BP_BASE/BP_BASE.DAT'

class Parser(object):
    def __init__(self, name, length, *args):
        self.name = name
        self.length = length
        self.args = args

    def parse(self, s):
        return NotImplementedError

class BinaryField(Parser):
    dtype=float
    def parse(self, s):
        if not s.strip():
            return None
        try:
            return self.args[0].index(s)
        except ValueError:
            return None

class IntField(Parser):
    dtype=float
    def parse(self, s):
        if not s.strip():
            return None
        return int(s)

class CategoryField(Parser):
    dtype='category'
    def parse(self, s):
        if self.args:
            if s in self.args[0]:
                return self.args[0][s]
        if not s.strip():
            return None
        return s

class StrField(Parser):
    dtype=str
    def parse(self, s):
        return s

class FloatField(Parser):
    dtype=float
    def parse(self, s):
        if s.strip() == '.':
            return None
        return float(s)

class DateField(Parser):
    dtype=object
    def parse(self, s):
        if not s.strip():
            return None
        Y = int(s[:2])
        if not s[2:].strip():
            M = None
        else:
            M = int(s[2:])
        if self.args and self.args[0] == True: # MMYY not YYMM.
            Y, M = M, Y
        return Y, M

race_coding = {str(i+1): s for i, s in enumerate('Amerindian Asian Black Mexican Puertorican Hispanic White Other'.split())}

data_format = [
    IntField('id', 5),
    CategoryField('sex', 1),
    CategoryField('race', 1, race_coding),
    IntField('origin_cluster', 1),
    IntField('degree_cluster', 1),
    FloatField('LSAT', 4),
    FloatField('UGPA', 3),
    StrField('', 1), #Unused column
    FloatField('ZFYA', 5),
    DateField('birth_date', 4, True), # reversed
    IntField('major', 1),
    CategoryField('graduated', 1),
    DateField('graduation_date', 4), #YYMM
    DateField('expected_graduation_date', 4), #YYMM
    FloatField('Zcum', 5), # Cumulative final LGPA standardized within school
    CategoryField('region_first', 2),
    CategoryField('region_last', 2),
    IntField('attempts', 1),
    BinaryField('first_pf', 1, 'FP'),
    DateField('first_pf_date', 4),
    BinaryField('last_pf', 1, 'FP'),
    DateField('last_pf_date', 4),
    ]

def parse_line_to_dict(s):
    cur_loc = 0
    ans = {}
    for field in data_format:
        value = field.parse(s[cur_loc:cur_loc+field.length])
        ans[field.name] = value
        cur_loc += field.length
    del ans['']
    return ans

def parse_file(filename=DATA_FILE):
    with open(filename) as f:
        rows = list(map(parse_line_to_dict, f))

    series = {}
    for field in data_format:
        if field.name == '':
            continue
        series[field.name] = pandas.Series([r[field.name] for r in rows], dtype=field.dtype)
    data = pandas.DataFrame(data=series)
    # Academic index used by Sander
    data['sander_index'] = data['LSAT']/data['LSAT'].max() * 0.6 + data['UGPA']/data['UGPA'].max() * 0.4
    return data
